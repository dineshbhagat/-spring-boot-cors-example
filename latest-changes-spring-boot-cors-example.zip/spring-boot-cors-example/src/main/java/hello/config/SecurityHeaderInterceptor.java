package hello.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class intercepts the request before the controller is invoked and
 * validates that the API key exists.
 */
public class SecurityHeaderInterceptor extends HandlerInterceptorAdapter {

    private static final Logger LOG = LoggerFactory.getLogger(SecurityHeaderInterceptor.class);

    /**
     * Validates security headers
     * 
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request,
        HttpServletResponse response, Object handler) throws Exception {

        String httpMethod = request.getMethod();
        LOG.info(" headers ", request.getHeaderNames());

        // Only care about security for non-GET, non-POST && non-OPTIONS requests.
        if (!httpMethod.equals(RequestMethod.GET.name()) &&
                !httpMethod.equals(RequestMethod.POST.name()) &&
                !httpMethod.equals(RequestMethod.OPTIONS.name()) &&
                !httpMethod.equals(RequestMethod.PUT.name()) &&
                !httpMethod.equals(RequestMethod.DELETE.name())) {
            throw new Exception("Not Allowed");
        }
        return true;
    }

}
